import React from 'react';
import { type LoadingViewError } from './types.js';
export declare const ErrorContent: React.FC<{
    error: LoadingViewError;
    onReload: () => void;
}>;
//# sourceMappingURL=ErrorContent.d.ts.map