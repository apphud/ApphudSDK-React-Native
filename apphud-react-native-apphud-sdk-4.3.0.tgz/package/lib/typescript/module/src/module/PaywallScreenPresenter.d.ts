import type { ApphudProduct, ApphudPurchaseResult, IDisposable, PlacementsOptions } from './types.js';
/**
 * Options for displaying the paywall screen.
 */
export type Options = {
    /**
     * Paywall placement identifier.
     * Used by the native layer to determine screen configuration.
     */
    placementIdentifier: string;
} & PlacementsOptions;
/**
 * List of event types that can be emitted by the paywall screen.
 */
declare const EVENT_TYPES: {
    /** Purchase transaction has started */
    readonly TRANSACTION_STARTED: "transactionStarted";
    /** Purchase transaction has completed successfully */
    readonly TRANSACTION_COMPLETED: "transactionCompleted";
    /** User tapped the close button */
    readonly CLOSE_BUTTON_TAPPED: "closeButtonTapped";
    /** An error occurred */
    readonly ERROR: "error";
    /** Paywall screen was shown */
    readonly SCREEN_SHOWN: "screenShown";
};
/**
 * Callback signatures for each event type.
 * Used to provide strict typing for event subscriptions.
 */
type EventCallbacks = {
    /**
     * Transaction start event.
     * @param product The product being purchased, or null
     */
    [EVENT_TYPES.TRANSACTION_STARTED]: (product: ApphudProduct | null) => void;
    /**
     * Transaction completion event.
     * @param result Purchase result
     */
    [EVENT_TYPES.TRANSACTION_COMPLETED]: (result: ApphudPurchaseResult) => void;
    /**
     * Close button tap event.
     */
    [EVENT_TYPES.CLOSE_BUTTON_TAPPED]: () => void;
    /**
     * Error event.
     * @param error Error object
     */
    [EVENT_TYPES.ERROR]: (error: any) => void;
    /**
     * Screen shown event.
     */
    [EVENT_TYPES.SCREEN_SHOWN]: () => void;
};
/**
 * Manages displaying the paywall screen and subscribing
 * to events emitted by the native layer.
 *
 * Each instance has a unique identifier used to:
 * - associate native events with the correct presenter
 * - isolate multiple paywall screens from each other
 */
export declare class PaywallScreenPresenter implements IDisposable {
    private readonly options;
    /**
     * Indicates whether this presenter has been disposed.
     * Once disposed, the instance must no longer be used.
     */
    private isDisposed;
    /**
     * Unique identifier of this presenter instance.
     * Used to filter events received from NativeEventEmitter.
     */
    private readonly id;
    /**
     * Collection of active event subscriptions.
     * Used to properly clean up listeners on dispose().
     */
    private subscriptions;
    /**
     * Creates a new PaywallScreenPresenter instance.
     *
     * @param options Paywall screen options
     */
    constructor(options?: Partial<Options>);
    /**
     * Displays the paywall screen.
     *
     * Passes the following data to the native layer:
     * - paywall options
     * - unique presenter identifier
     */
    displayPaywallScreen(): void;
    /**
     * Subscribes to a paywall screen event.
     *
     * The callback will only be invoked if the event
     * belongs to the current presenter instance.
     *
     * @template Name
     * @param name Event type
     * @param callback Event handler
     * @returns Function to unsubscribe from the event
     */
    addEventListener<Name extends keyof EventCallbacks>(name: Name, callback: EventCallbacks[Name]): () => void;
    /**
     * Disposes the presenter instance.
     *
     * - Removes all event subscriptions
     * - Prevents further callbacks from being invoked
     * - Releases associated resources
     */
    dispose(): void;
}
export {};
//# sourceMappingURL=PaywallScreenPresenter.d.ts.map