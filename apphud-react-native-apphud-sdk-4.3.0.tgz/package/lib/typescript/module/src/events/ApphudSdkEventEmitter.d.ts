import type { ApphudProduct, ApphudSubscription, ApphudNonRenewingPurchase, ApphudPlacement, ApphudUser } from '../module/index.js';
import type { ApphudPurchaseEventResult, ApphudDidFailPurchaseEventResult, ApphudScreenDidAppearResult, ApphudDidSelectSurveyAnswerResult, ApphudDeeplinkAttribution, ApphudRuleScreenDidAppearResult, ApphudRuleWillPurchaseResult, ApphudRulePurchaseCompletedResult, ApphudRuleScreenWillDismissResult, ApphudRuleScreenDidDismissResult, ApphudRuleDidSelectSurveyAnswerResult, ApphudRulePaywallWithoutScreenResult } from './types.js';
type Callback<Arg = void> = Arg extends void ? () => void : (arg: Arg) => void;
interface IApphudSdkEventEmitter {
    /**
     * Called when placements are fully loaded with their Paywalls and store products.
     *
     * Available on iOS and Android.
     */
    onPlacementsDidFullyLoad(cb: Callback<ApphudPlacement[]>): Callback;
    /**
     * Called once per app lifecycle when the user is registered or retrieved from cache.
     *
     * Available on iOS and Android.
     */
    onUserDidLoad(cb: Callback<ApphudUser>): Callback;
    /**
     * Called when store products are loaded with their `SKProducts` / `ProductDetails`.
     * It's not recommended to use this event. Use `onPlacementsDidFullyLoad` instead.
     *
     * Available on iOS and Android.
     */
    onApphudDidLoadStoreProducts(cb: Callback<ApphudProduct[]>): Callback;
    /**
     * Called when user ID has been changed. Use this if you implement integrations with Analytics services.
     *
     *  Available on iOS and Android.
     */
    onApphudDidChangeUserID(cb: Callback<string>): Callback;
    /**
     * Returns array of subscriptions that user ever purchased. Empty array means user never purchased a subscription.
     *
     * Available on iOS and Android.
     */
    onApphudSubscriptionsUpdated(cb: Callback<ApphudSubscription[]>): Callback;
    /**
     * Called when any of non renewing purchases changes. Called when purchase is made or has been refunded.
     *
     * Available on iOS and Android.
     */
    onApphudNonRenewingPurchasesUpdated(cb: Callback<ApphudNonRenewingPurchase[]>): Callback;
    /**
     * Called when a Rules Screen appeared.
     *
     * @deprecated Prefer `onApphudRuleScreenDidAppear`. Available on iOS only.
     */
    onApphudScreenDidAppear(cb: Callback<ApphudScreenDidAppearResult>): Callback;
    /**
     * Called when user successfully purchases in a Rules Screen.
     *
     * @deprecated Prefer `onApphudRulePurchaseCompleted`. Available on iOS only.
     */
    onApphudDidPurchase(cb: Callback<ApphudPurchaseEventResult>): Callback;
    /**
     * Called when user is about to make purchase in a Rules Screen.
     *
     * @deprecated Prefer `onApphudRuleWillPurchase`. Available on iOS only.
     */
    onApphudWillPurchase(cb: Callback<ApphudPurchaseEventResult>): Callback;
    /**
     * Called when user failed to make a purchase in a Rules Screen.
     *
     * @deprecated Prefer `onApphudRulePurchaseCompleted`. Available on iOS only.
     */
    onApphudDidFailPurchase(cb: Callback<ApphudDidFailPurchaseEventResult>): Callback;
    /**
     * Called when user answers a survey in a Rules Screen.
     *
     * @deprecated Prefer `onApphudRuleDidSelectSurveyAnswer`. Available on iOS only.
     */
    onApphudDidSelectSurveyAnswer(cb: Callback<ApphudDidSelectSurveyAnswerResult>): Callback;
    /**
     * Called when a rule-triggered screen (Figma paywall or legacy HTML) is visible.
     *
     * Available on iOS and Android.
     */
    onApphudRuleScreenDidAppear(cb: Callback<ApphudRuleScreenDidAppearResult>): Callback;
    /**
     * Called when the user taps purchase (or restore) on a rule screen.
     *
     * Available on iOS and Android.
     */
    onApphudRuleWillPurchase(cb: Callback<ApphudRuleWillPurchaseResult>): Callback;
    /**
     * Called when a purchase from a rule screen finishes (success or failure).
     *
     * Available on iOS and Android.
     */
    onApphudRulePurchaseCompleted(cb: Callback<ApphudRulePurchaseCompletedResult>): Callback;
    /**
     * Called when a rule screen is about to dismiss.
     *
     * Available on iOS and Android.
     */
    onApphudRuleScreenWillDismiss(cb: Callback<ApphudRuleScreenWillDismissResult>): Callback;
    /**
     * Called after a rule screen has been dismissed.
     *
     * Available on iOS and Android.
     */
    onApphudRuleScreenDidDismiss(cb: Callback<ApphudRuleScreenDidDismissResult>): Callback;
    /**
     * Called after a survey answer is selected on a legacy HTML rule screen.
     *
     * Available on iOS and Android.
     */
    onApphudRuleDidSelectSurveyAnswer(cb: Callback<ApphudRuleDidSelectSurveyAnswerResult>): Callback;
    /**
     * Called when a paywall rule has no visual screen payload.
     * Present the paywall yourself (e.g. via `PaywallScreenView` / `createPresenter`).
     *
     * Available on iOS and Android.
     */
    onApphudRulePaywallWithoutScreen(cb: Callback<ApphudRulePaywallWithoutScreenResult>): Callback;
    /**
     * Called when deep link attribution is resolved, for both direct (link open) and
     * deferred (install) flows. May be called multiple times during the app lifecycle.
     * When no attribution match is found, `attribution` is an empty object.
     *
     * To receive `direct` attribution, forward incoming links to
     * `ApphudSdk.handleDeeplinkUrl(url)`. To request `deferred` attribution, call
     * `ApphudSdk.requestDeferredDeeplinkAttribution()`.
     *
     * Available on iOS and Android.
     */
    onApphudDeeplinkAttribution(cb: Callback<ApphudDeeplinkAttribution>): Callback;
    /**
     * Specify a list of product identifiers to fetch from the App Store.
     *
     * Available on iOS only.
     */
    setApphudProductIdentifiers(ids: string[]): Promise<string[]>;
}
export declare const ApphudSdkEventEmitter: IApphudSdkEventEmitter;
export {};
//# sourceMappingURL=ApphudSdkEventEmitter.d.ts.map