export interface LoadingViewError {
    code: number;
    localizedDescription: string;
    userInfo: Record<string, any>;
}
//# sourceMappingURL=types.d.ts.map