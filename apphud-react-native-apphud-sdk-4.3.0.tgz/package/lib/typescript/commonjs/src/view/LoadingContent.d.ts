import React from 'react';
export declare const LoadingContent: React.FC;
//# sourceMappingURL=LoadingContent.d.ts.map