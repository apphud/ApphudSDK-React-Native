import React, { type ReactElement } from 'react';
import { type NativeSyntheticEvent, type ViewStyle, type ViewProps } from 'react-native';
import { type ApphudProduct, type ApphudPurchaseResult, type PlacementsOptions } from '../module';
import { type LoadingViewError } from './types';
type Props = ViewProps & {
    /**
     * Paywall placement identifier.
     * Determines which paywall configuration should be displayed.
     */
    placementIdentifier: string;
    /**
     * Options for requesting placements, such as retry attempts and force refresh.
     * This prop is optional and can be used to customize the behavior of placement requests.
     * If not provided, default options will be used.
     *
     * Use as const or use the `useMemo` (`useRef`) hook for remove rerendering on every render due to object reference change.
     *
     * Example usage:
     * ```tsx
     * const REQUEST_PLACEMENTS_OPTIONS = { maxAttempts: 4, forceRefresh: true };
     *
     * <PaywallScreenView
     *   placementIdentifier={placementId}
     *   requestPlacementsOptions={REQUEST_PLACEMENTS_OPTIONS}
     * />
     * ```
     */
    requestPlacementsOptions?: Partial<PlacementsOptions>;
    /**
     * Called when the paywall starts loading.
     */
    onStartLoading?: (event: NativeSyntheticEvent<{
        placementIdentifier: string;
    }>) => void;
    /**
     * Called when the native paywall view is fully received and rendered.
     */
    onReceiveView?: (event: NativeSyntheticEvent<{}>) => void;
    /**
     * Called when an error occurs while loading the paywall.
     */
    onLoadingError?: (event: NativeSyntheticEvent<{
        placementIdentifier: string;
        error: LoadingViewError;
    }>) => void;
    /**
     * Called when a purchase transaction starts.
     */
    onTransactionStarted?: (event: NativeSyntheticEvent<{
        result: ApphudProduct | null;
    }>) => void;
    /**
     * Called when a purchase transaction completes.
     */
    onTransactionCompleted?: (event: NativeSyntheticEvent<{
        result: ApphudPurchaseResult | null;
    }>) => void;
    /**
     * Called when the user taps the close button.
     */
    onCloseButtonTapped?: (event: NativeSyntheticEvent<{}>) => void;
    /**
     * Style applied to the native view.
     */
    style?: ViewStyle;
    /**
     * Custom renderer for the loading state.
     */
    renderLoading?: () => ReactElement;
    /**
     * Custom renderer for the error state.
     */
    renderError?: (error: LoadingViewError, onReload: () => void) => ReactElement;
};
/**
 * React component that displays a native paywall screen.
 * The way for usage - react-navigation screen (modal)
 *
 * This component:
 * - wraps the native paywall view
 * - manages loading and error overlay states
 * - provides default UI for loading and error states
 * - exposes lifecycle and purchase-related callbacks
 *
 * The paywall content itself is rendered natively.
 *
 * @example
 * ```tsx
 * <PaywallScreenView
 *   placementIdentifier={placementId}
 *   onTransactionCompleted={(event) => {
 *     console.log(event.nativeEvent.result);
 *   }}
 * />
 * ```
 */
export declare const PaywallScreenView: React.FC<Props>;
export {};
//# sourceMappingURL=PaywallScreenView.d.ts.map