export declare function getDefaultApiKey(): string;
export declare function getStoredApiKey(): Promise<string | null>;
export declare function setStoredApiKey(apiKey: string): Promise<void>;
export declare function clearStoredApiKey(): Promise<void>;
type StartSessionOptions = {
    apiKey?: string | null;
    userId?: string | null;
    deviceId?: string | null;
    persist?: boolean;
};
export declare function startApphudSession({ apiKey, userId, deviceId, persist, }?: StartSessionOptions): Promise<string>;
export {};
//# sourceMappingURL=session.d.ts.map