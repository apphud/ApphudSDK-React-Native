import React from 'react';
export default function UpdateUserIDScreen(): React.JSX.Element;
//# sourceMappingURL=UpdateUserIDScreen.d.ts.map