import * as React from 'react';
import type { Props } from './LoginScreen';
export default function ActionsScreen({ navigation }: Props): React.JSX.Element;
//# sourceMappingURL=ActionsScreen.d.ts.map