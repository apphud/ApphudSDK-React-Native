import * as React from 'react';
export default function PlacementsScreen(): React.JSX.Element;
//# sourceMappingURL=PlacementsScreen.d.ts.map