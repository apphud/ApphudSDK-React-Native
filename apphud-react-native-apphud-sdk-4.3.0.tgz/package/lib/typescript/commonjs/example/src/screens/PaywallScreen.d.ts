import * as React from 'react';
export default function PaywallScreen({ route, navigation, }: {
    route: {
        params: {
            placementId: string;
        };
    };
    navigation: any;
}): React.JSX.Element;
//# sourceMappingURL=PaywallScreen.d.ts.map