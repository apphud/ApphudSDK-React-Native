import * as React from 'react';
import type { StackScreenProps } from '@react-navigation/stack';
export type Props = StackScreenProps<any>;
export default function LoginScreen({ navigation }: Props): React.JSX.Element;
//# sourceMappingURL=LoginScreen.d.ts.map