import * as React from 'react';
export default function ProductsScreen(): React.JSX.Element;
//# sourceMappingURL=ProductsScreen.d.ts.map