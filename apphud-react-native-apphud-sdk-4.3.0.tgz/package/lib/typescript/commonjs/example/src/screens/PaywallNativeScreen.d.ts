import React from 'react';
declare const PaywallNativeScreen: () => React.JSX.Element;
export default PaywallNativeScreen;
//# sourceMappingURL=PaywallNativeScreen.d.ts.map