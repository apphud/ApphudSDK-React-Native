import React from 'react';
export default function SetAttributionScreen(): React.JSX.Element;
//# sourceMappingURL=SetAttributionScreen.d.ts.map