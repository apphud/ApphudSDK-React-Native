export declare const common: {
    th: {
        fontWeight: "bold";
    };
    table: {
        borderTopWidth: number;
        borderTopColor: string;
        borderLeftWidth: number;
        borderLeftColor: string;
        marginBottom: number;
    };
    row: {
        display: "flex";
        flexDirection: "row";
        backgroundColor: string;
    };
    col: {
        flex: number;
        padding: number;
        borderBottomWidth: number;
        borderBottomColor: string;
        borderRightWidth: number;
        borderRightColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map