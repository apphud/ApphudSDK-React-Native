import * as React from 'react';
import { type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
/**
 * Minimal replacements for the handful of `react-native-elements` widgets the
 * demo used. That package is unmaintained and does not support React 19, so the
 * screens render plain React Native primitives instead.
 */
type InputProps = {
    placeholder?: string;
    value: string;
    onChangeText: (text: string) => void;
    secureTextEntry?: boolean;
};
export declare function Input({ placeholder, value, onChangeText, secureTextEntry, }: InputProps): React.JSX.Element;
type ButtonProps = {
    title: string;
    onPress: () => void;
    disabled?: boolean;
    loading?: boolean;
};
export declare function Button({ title, onPress, disabled, loading }: ButtonProps): React.JSX.Element;
type ListItemProps = {
    children: React.ReactNode;
    containerStyle?: StyleProp<ViewStyle>;
    onPress?: () => void;
};
type TextSlotProps = {
    children: React.ReactNode;
    style?: StyleProp<TextStyle>;
};
declare function ListItemRoot({ children, containerStyle, onPress }: ListItemProps): React.JSX.Element;
export declare const ListItem: typeof ListItemRoot & {
    Content: ({ children }: {
        children: React.ReactNode;
    }) => React.JSX.Element;
    Title: ({ children, style }: TextSlotProps) => React.JSX.Element;
    Subtitle: ({ children, style }: TextSlotProps) => React.JSX.Element;
    Chevron: () => React.JSX.Element;
};
export {};
//# sourceMappingURL=ui.d.ts.map