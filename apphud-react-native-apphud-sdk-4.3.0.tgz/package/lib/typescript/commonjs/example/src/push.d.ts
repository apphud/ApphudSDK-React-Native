/**
 * Re-submit the platform push token to Apphud after `Apphud.start`.
 *
 * - iOS: re-submits the cached APNs token (or triggers registration if none yet).
 * - Android: fetches the current FCM token and submits it.
 *
 * Native FCM / APNs handlers also submit automatically when a token arrives;
 * this call covers the common case where the token was received before start.
 */
export declare function submitExamplePushToken(): Promise<boolean>;
//# sourceMappingURL=push.d.ts.map