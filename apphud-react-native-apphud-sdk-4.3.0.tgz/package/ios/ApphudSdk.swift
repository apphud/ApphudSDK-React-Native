import ApphudSDK
import StoreKit

/// Implementation behind the `ApphudSdk` Turbo Native Module.
///
/// The module itself is `ApphudSdkModule` (Obj-C++), because Codegen generates
/// the `NativeApphudSdkSpec` protocol as Obj-C++, which Swift cannot import.
/// This class holds all the logic and is called through the generated
/// `-Swift.h` header, so its API has to be `public` and Obj-C representable.
@objc(ApphudSdkImpl)
public final class ApphudSdkImpl: NSObject {

  private func applyBaseUrl(from options: NSDictionary) {
    if let baseUrl = options["baseUrl"] as? String, !baseUrl.isEmpty {
      ApphudHttpClient.shared.domainUrlString = baseUrl
    }
  }

  public override init() {
    ApphudHttpClient.shared.sdkType = "reactnative"
    let current = ApphudHttpClient.shared.sdkVersion
    if !current.contains("(") {
      ApphudHttpClient.shared.sdkVersion = ApphudSdkVersion.value + "(\(current))"
    }
  }

  @objc(start:withResolver:withRejecter:)
  public func start(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: RCTPromiseRejectBlock
  ) {

    guard let apiKey = options["apiKey"] as? String else {
      reject("Error", "apiKey not set", nil)
      return
    }

    let userID = options["userId"] as? String;
    let observerMode = options["observerMode"] as? Bool ?? false;
    applyBaseUrl(from: options)

    DispatchQueue.main.async {
#if DEBUG
      ApphudUtils.enableAllLogs()
#endif

      // JS can remount while the process-scoped native SDK is still initialized.
      // Return the existing user instead of calling start again.
      if let user = Apphud.currentUser() {
        resolve(user.toMap())
        return
      }

      Apphud
        .start(
          apiKey: apiKey,
          userID: userID,
          observerMode: observerMode
        ) { user in
          Task { @MainActor in
            resolve(user.toMap())
          }
        }

      // `start` resets the deep link handler when it's not passed as an argument.
      ApphudSdkEventsImpl.reapplyDeeplinkHandlerIfNeeded()
    }
  }

  @objc(startManually:withResolver:withRejecter:)
  public func startManually(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: RCTPromiseRejectBlock
  ) {
    guard let apiKey = options["apiKey"] as? String else {
      reject("Error", "apiKey not set", nil)
      return
    }

    let userID = options["userId"] as? String;
    let deviceID = options["deviceId"] as? String;
    let observerMode = options["observerMode"] as? Bool ?? false;
    applyBaseUrl(from: options)

#if DEBUG
      ApphudUtils.enableAllLogs()
#endif


    DispatchQueue.main.async {
      if let user = Apphud.currentUser() {
        resolve(user.toMap())
        return
      }

      Apphud
        .startManually(
          apiKey: apiKey,
          userID: userID,
          deviceID: deviceID,
          observerMode: observerMode
        ) { user in
          Task { @MainActor in
            resolve(user.toMap())
          }
        }

      // `startManually` resets the deep link handler when it's not passed as an argument.
      ApphudSdkEventsImpl.reapplyDeeplinkHandlerIfNeeded()
    }
  }

  @objc(setHost:)
  public func setHost(url: String) {
    ApphudHttpClient.shared.domainUrlString = url
  }

  @objc(handleDeeplinkUrl:)
  public func handleDeeplinkUrl(url: String) {
    guard let deeplinkUrl = URL(string: url) else { return }

    Task { @MainActor in
      Apphud.handleOpen(url: deeplinkUrl)
    }
  }

  @objc(requestDeferredDeeplinkAttribution:withRejecter:)
  public func requestDeferredDeeplinkAttribution(
    resolve: @escaping RCTPromiseResolveBlock,
    reject: RCTPromiseRejectBlock
  ) {
    Task { @MainActor in
      Apphud.requestDeferredDeeplinkAttribution()
      resolve(nil)
    }
  }

  @objc(rawPlacements:withRejecter:)
  public func rawPlacements(
    resolve: @escaping RCTPromiseResolveBlock,
    reject: RCTPromiseRejectBlock
  ) {
    Task { @MainActor in
      resolve(Apphud.rawPlacements().map { $0.toMap() })
    }
  }

  @objc(placement:options:withResolver:withRejecter:)
  public func placement(
    identifier: String,
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    let maxAttempts = options["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    Task { @MainActor in
      if let placement = await Apphud.placement(identifier) {
        resolve(placement.toMap())
      } else {
        resolve(NSNull())
      }
    }
  }

  @objc(isCommitmentPlanPreferred:withResolver:withRejecter:)
  public func isCommitmentPlanPreferred(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    guard let productId = options["productId"] as? String, !productId.isEmpty else {
      reject("Error", "productId not set", nil)
      return
    }
    let placementId = options["placementIdentifier"] as? String
    let paywallId = options["paywallIdentifier"] as? String
    let maxAttempts = options["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    let forceRefresh = options["forceRefresh"] as? Bool ?? false

    Task { @MainActor in
      guard let product = await ApphudPaywallsHelper.findProduct(
        productId: productId,
        placementIdentifier: placementId,
        paywallIdentifier: paywallId,
        maxAttempts: maxAttempts,
        forceRefresh: forceRefresh
      ) else {
        resolve(false)
        return
      }
      resolve(product.isCommitmentPlanPreferred())
    }
  }

  @objc(isCommitmentPlanSupported:withResolver:withRejecter:)
  public func isCommitmentPlanSupported(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    guard let productId = options["productId"] as? String, !productId.isEmpty else {
      reject("Error", "productId not set", nil)
      return
    }
    let placementId = options["placementIdentifier"] as? String
    let paywallId = options["paywallIdentifier"] as? String
    let maxAttempts = options["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    let forceRefresh = options["forceRefresh"] as? Bool ?? false

    Task { @MainActor in
      guard let product = await ApphudPaywallsHelper.findProduct(
        productId: productId,
        placementIdentifier: placementId,
        paywallIdentifier: paywallId,
        maxAttempts: maxAttempts,
        forceRefresh: forceRefresh
      ) else {
        resolve(false)
        return
      }
      if #available(iOS 26.4, *) {
        let supported = await product.isCommitmentPlanSupported()
        resolve(supported)
      } else {
        resolve(false)
      }
    }
  }

  @MainActor
  @objc(refreshUserData:withRejecter:)
  public func refreshUserData(resolve: @escaping RCTPromiseResolveBlock,
                              reject: RCTPromiseRejectBlock) {
    Apphud.refreshUserData { user in
      resolve(user?.toMap())
    }
  }

  @objc(logout:withRejecter:)
  public func logout(
    resolve: @escaping RCTPromiseResolveBlock,
    reject:RCTPromiseRejectBlock
  ) {
    Task {
      await Apphud.logout()
      resolve(nil)
    }
  }

  @objc(hasActiveSubscription:withRejecter:)
  public func hasActiveSubscription(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    resolve(Apphud.hasActiveSubscription());
  }

  @objc(hasPremiumAccess:withRejecter:)
  public func hasPremiumAccess(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    resolve(Apphud.hasPremiumAccess());
  }

  @objc(products:withRejecter:)
  public func products(resolve: @escaping RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    Apphud.fetchProducts { products, error in

      resolve(products.map { $0.toMap() });
    }
  }

  @objc(purchase:withResolver:withRejecter:)
  public func purchase(args: NSDictionary, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) -> Void {
    Task { @MainActor in
      guard let product = await self.findProduct(from: args) else {
        if (args["productId"] as? String)?.isEmpty != false {
          reject("Error", "ProductId not set", nil)
        } else {
          reject("Error", "Product not found", nil)
        }
        return
      }

      Apphud.purchase(product) { result in
        Self.resolvePurchase(result, resolve: resolve)
      }
    }
  }

  @objc(checkEligibilityForPromotionalOffer:withResolver:withRejecter:)
  public func checkEligibilityForPromotionalOffer(
    args: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) -> Void {
    Task { @MainActor in
      guard let apphudProduct = await self.findProduct(from: args) else {
        if (args["productId"] as? String)?.isEmpty != false {
          reject("Error", "ProductId not set", nil)
        } else {
          reject("Error", "Product not found", nil)
        }
        return
      }

      guard let skProduct = apphudProduct.skProduct else {
        reject("Error", "SKProduct not available", nil)
        return
      }

      Apphud.checkEligibilityForPromotionalOffer(product: skProduct) { eligible in
        DispatchQueue.main.async {
          resolve(eligible)
        }
      }
    }
  }

  @objc(purchasePromo:withResolver:withRejecter:)
  public func purchasePromo(args: NSDictionary, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) -> Void {
    guard let discountID = args["discountID"] as? String, !discountID.isEmpty else {
      reject("Error", "discountID not set", nil)
      return
    }

    Task { @MainActor in
      guard let apphudProduct = await self.findProduct(from: args) else {
        if (args["productId"] as? String)?.isEmpty != false {
          reject("Error", "ProductId not set", nil)
        } else {
          reject("Error", "Product not found", nil)
        }
        return
      }

      Apphud.purchasePromo(apphudProduct: apphudProduct, discountID: discountID) { result in
        Self.resolvePurchase(result, resolve: resolve)
      }
    }
  }

  @objc(paywallShown:)
  public func paywallShown(options: [AnyHashable : Any]) {
    let placementIdentifier = options["placementIdentifier"] as? String
    let paywallIdentifier = options["paywallIdentifier"] as? String

    if placementIdentifier == nil && paywallIdentifier == nil {
      return
    }

    Task { @MainActor in
      let paywall = await ApphudPaywallsHelper.getPaywall(options: options)

      if let paywall {
        Apphud.paywallShown(paywall)
      }
    }
  }

  @MainActor @objc(subscription:withRejecter:)
  public func subscription(resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    guard let subscription = Apphud.subscription() else {
      reject("Error", "User has no subscriptions", nil)
      return
    }

    resolve(subscription.toMap());
  }


  @MainActor @objc(subscriptions:withRejecter:)
  public func subscriptions(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    let subs = Apphud.subscriptions() ?? []
    let array: Array = subs.map { $0.toMap() }
    resolve(array as NSArray)
  }

  @MainActor @objc(isNonRenewingPurchaseActive:withResolver:withRejecter:)
  public func isNonRenewingPurchaseActive(productIdentifier: String, resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    resolve(
      Apphud.isNonRenewingPurchaseActive(productIdentifier: productIdentifier)
    );
  }

  @MainActor @objc(nonRenewingPurchases:withRejecter:)
  public func nonRenewingPurchases(resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    let purchases = Apphud.nonRenewingPurchases() ?? []
    let array: Array = purchases.map { $0.toMap() }
    resolve(array)
  }

  @MainActor @objc(restorePurchases:withRejecter:)
  public func restorePurchases(resolve: @escaping RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    Apphud.restorePurchases { result in
      resolve(
        [
          "subscriptions": (result.subscription != nil) ? [result.subscription?.toMap()] : [],
          "purchases": (result.nonRenewingPurchase != nil) ? [result.nonRenewingPurchase?.toMap()] : [],
          "error": result.error?.localizedDescription as Any
        ]
      )
    }
  }

  @MainActor @objc(userId:withRejecter:)
  public func userId(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    resolve(
      Apphud.userID()
    );
  }

  @objc(setAttribution:withResolver:withRejecter:)
  public func setAttribution(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject:RCTPromiseRejectBlock
  ) {
    guard let attributionParams = options.getAttributionParams() else {
      reject("Error", "Options not valid", nil)
      return
    }

    Apphud
      .setAttribution(
        data: attributionParams.data,
        from: attributionParams.provider,
        identifer: attributionParams.identifier
      ) { res, dict in
        resolve(res)
      }
  }

  @objc(setUserProperty:)
  public func setUserProperty(options: NSDictionary) {
    guard let key = options["key"] as? String else {return}

    let value = options["value"]
    let setOnce: Bool = (options["setOnce"] as? Bool) ?? false
    let _key = ApphudUserPropertyKey.init(key)
    Apphud.setUserProperty(key: _key, value: value, setOnce: setOnce)
  }

  @objc(incrementUserProperty:)
  public func incrementUserProperty(options: NSDictionary) {
    guard let key = options["key"] as? String, let by = options["by"] else {
      return
    }

    let _key = ApphudUserPropertyKey.init(key)
    Apphud.incrementUserProperty(key: _key, by: by)
  }

  // TODO
  @MainActor @objc(syncPurchasesInObserverMode:withRejecter:)
  public func syncPurchasesInObserverMode(resolve: @escaping RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    Apphud.restorePurchases { result in
      resolve(result.error == nil)
    }
  }

  @objc(setDeviceIdentifiers:)
  public func setDeviceIdentifiers(options: NSDictionary) {
    let idfa = options["idfa"] as? String
    let idfv = options["idfv"] as? String

    Apphud.setDeviceIdentifiers(idfa: idfa, idfv: idfv)
  }

  @objc(enableDebugLogs)
  public func enableDebugLogs() {
    ApphudUtils.enableAllLogs()
  }

  @objc(optOutOfTracking)
  public func optOutOfTracking() {
    Apphud.optOutOfTracking()
  }

  @objc(collectDeviceIdentifiers)
  public func collectDeviceIdentifiers() {
    // do nothing
  }

  @objc(checkRules:withRejecter:)
  public func checkRules(
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    DispatchQueue.main.async {
      ApphudUtils.checkRules()
      resolve(nil)
    }
  }

  @MainActor
  @objc(pendingRule:withRejecter:)
  public func pendingRule(
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    if let rule = Apphud.pendingRule() {
      var map: [String: Any] = [:]
      for (key, value) in rule.toMap() {
        map[key] = value ?? NSNull()
      }
      resolve(map)
    } else {
      resolve(nil)
    }
  }

  @MainActor
  @objc(showPendingRuleScreen:withRejecter:)
  public func showPendingRuleScreen(
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    let hasPending = Apphud.pendingRuleScreenController() != nil
    if hasPending {
      Apphud.showPendingRuleScreen()
    }
    resolve(hasPending)
  }

  @objc(submitPushNotificationsToken:withResolver:withRejecter:)
  public func submitPushNotificationsToken(
    token: String,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    Apphud.submitPushNotificationsTokenString(string: token) { success in
      resolve(success)
    }
  }

  @objc(handlePushNotification:withResolver:withRejecter:)
  public func handlePushNotification(
    apsInfo: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    guard let payload = apsInfo as? [AnyHashable: Any] else {
      resolve(false)
      return
    }
    DispatchQueue.main.async {
      let handled = Apphud.handlePushNotification(apsInfo: payload)
      resolve(handled)
    }
  }

  @MainActor @objc(attributeFromWeb:withResolver:withRejecter:)
  public func attributeFromWeb(
    data: [AnyHashable: Any],
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock) {
      Apphud.attributeFromWeb(data: data) { success, user in

        var result: [String: Any] = [:]

        if let userId = user?.userId {
          result["userId"] = userId
        }

        result["isPremium"] = Apphud.hasPremiumAccess()
        result["result"] = success

        resolve(result)
      }
    }

  @MainActor @objc(placements:withResolver:withRejecter:)
  public func placements(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    let maxAttempts = options["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    let forceRefresh = options["forceRefresh"] as? Bool ?? false

    Apphud.fetchPlacements(maxAttempts: maxAttempts, forceRefresh: forceRefresh) { placements, error in
      if let error {
        reject("Error", error.localizedDescription, nil)
        return
      }

      resolve(placements.map({ $0.toMap() }))
    }
  }

  @MainActor
  @objc(preloadPaywallScreens:)
  public func preloadPaywallScreens(placementIdentifiers: [String]) {
    Apphud.preloadPaywallScreens(placementIdentifiers: placementIdentifiers)
  }

  @MainActor
  @objc(unloadPaywallScreen:withResolver:withRejecter:)
  public func unloadPaywallScreen(
    options: NSDictionary,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {
    guard let placementIdentifier = options["placementIdentifier"] as? String else {
      reject("Error", "Param placementIdentifier is required", nil)
      return
    }

    let maxAttempts = options["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    let forceRefresh = options["forceRefresh"] as? Bool ?? false

    Apphud.fetchPlacements(maxAttempts: maxAttempts, forceRefresh: forceRefresh) { [resolve, reject] placements, error in
      if let error {
        reject("Error", error.localizedDescription, nil)
        return
      }

      let placement = placements.first { placement in
        placement.identifier == placementIdentifier
      }

      guard let paywall = placement?.paywall else {
        reject("Error", "Paywall not found", nil)
        return
      }

      Apphud.unloadPaywallScreen(paywall)
      resolve(nil)
    }
  }

  @objc(idfv:withRejecter:)
  public func idfv(resolve: RCTPromiseResolveBlock, reject: RCTPromiseRejectBlock) {
    resolve(UIDevice.current.identifierForVendor?.uuidString)
  }

  @MainActor
  @objc(updateUserID:withResolver:withRejecter:)
  public func updateUserID(userID: String, resolve: @escaping RCTPromiseResolveBlock, reject: RCTPromiseRejectBlock) {
    Apphud.updateUserID(userID) { user in
      Task { @MainActor in
        resolve(user?.toMap())
      }
    }
  }
}

private extension ApphudSdkImpl {
  @MainActor
  func findProduct(from args: NSDictionary) async -> ApphudProduct? {
    guard let productId = args["productId"] as? String, !productId.isEmpty else {
      return nil
    }

    let paywallId = args["paywallIdentifier"] as? String
    let placementId = args["placementIdentifier"] as? String
    let maxAttempts = args["maxAttempts"] as? Int ?? APPHUD_DEFAULT_RETRIES
    let forceRefresh = args["forceRefresh"] as? Bool ?? false

    return await ApphudPaywallsHelper.findProduct(
      productId: productId,
      placementIdentifier: placementId,
      paywallIdentifier: paywallId,
      maxAttempts: maxAttempts,
      forceRefresh: forceRefresh
    )
  }

  static func resolvePurchase(
    _ result: ApphudPurchaseResult,
    resolve: @escaping RCTPromiseResolveBlock
  ) {
    DispatchQueue.main.async {
      var response = [String: Any]()
      response["success"] = result.error == nil

      if let sub = result.subscription?.toMap() {
        response["subscription"] = sub
      }
      if let non = result.nonRenewingPurchase?.toMap() {
        response["nonRenewingPurchase"] = non
      }

      if let skError = result.error as? SKError, skError.code == .paymentCancelled {
        response["userCanceled"] = NSNumber(booleanLiteral: true)
      }

      if let err = result.error as? NSError {
        response["error"] = [
          "code": err.code,
          "message": err.localizedDescription,
        ]
      }

      if let transaction = result.transaction {
        response["transaction"] = [
          "state": transaction.transactionState.rawValue,
          "id": transaction.transactionIdentifier as Any,
          "date": transaction.transactionDate?.timeIntervalSince1970 as Any,
          "productId": transaction.payment.productIdentifier,
        ]
      }

      resolve(response)
    }
  }
}
